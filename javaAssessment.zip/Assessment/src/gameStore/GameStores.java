package gameStore;

import java.util.Scanner;

public class GameStores {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int price1 = 1500;
        int price2 = 1200;
        int price3 = 1000;
        int price4 = 800;
        int price5 = 500;

        int qty1 = 0, qty2 = 0, qty3 = 0, qty4 = 0, qty5 = 0;

        int choice;

        do {
           
            System.out.println("Welcome to the Game Store");
            System.out.println("1. Call of Warfare - ₹1500");
            System.out.println("2. Speed Racers - ₹1200");
            System.out.println("3. Mystery Mansion - ₹1000");
            System.out.println("4. Pixel Adventure - ₹800");
            System.out.println("5. Puzzle Mania - ₹500");
            System.out.println("6. Checkout / Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            if (choice == 1) {
                System.out.print("How many copies of Call of Warfare? ");
                qty1 += scanner.nextInt();
                System.out.println();
            } else if (choice == 2) {
                System.out.print("How many copies of Speed Racers? ");
                qty2 += scanner.nextInt();
                System.out.println();
            } else if (choice == 3) {
                System.out.print("How many copies of Mystery Mansion? ");
                qty3 += scanner.nextInt();
                System.out.println();
            } else if (choice == 4) {
                System.out.print("How many copies of Pixel Adventure? ");
                qty4 += scanner.nextInt();
                System.out.println();
            } else if (choice == 5) {
                System.out.print("How many copies of Puzzle Mania? ");
                qty5 += scanner.nextInt();
                System.out.println();
            } else if (choice == 6) {
       
                int total = 0;
                System.out.println("Checkout");
                if (qty1 > 0) {
                    int cost = qty1 * price1;
                    System.out.println("Call of Warfare x " + qty1 + " = " + cost);
                    total += cost;
                }
                if (qty2 > 0) {
                    int cost = qty2 * price2;
                    System.out.println("Speed Racers x " + qty2 + " = " + cost);
                    total += cost;
                }
                if (qty3 > 0) {
                    int cost = qty3 * price3;
                    System.out.println("Mystery Mansion x " + qty3 + " = " + cost);
                    total += cost;
                }
                if (qty4 > 0) {
                    int cost = qty4 * price4;
                    System.out.println("Pixel Adventure x " + qty4 + " = " + cost);
                    total += cost;
                }
                if (qty5 > 0) {
                    int cost = qty5 * price5;
                    System.out.println("Puzzle Mania x " + qty5 + " = " + cost);
                    total += cost;
                }

                System.out.println("Total cost:" + total);
            } else {
                System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 6);

        scanner.close();
    }
}

